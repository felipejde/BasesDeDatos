Práctica 8

Alpuche Morales Elmer Alexis - 415975945
elmer.alpuche@ciencias.unam.mx

Cova Pacheco Felipe de Jesús - 312030111
felipejde.fc@ciencias.unam.mx